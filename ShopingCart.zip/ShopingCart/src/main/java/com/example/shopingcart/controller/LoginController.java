package com.example.shopingcart.controller;

import com.example.shopingcart.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(String email, String name, Model model) {
        if (userService.authenticate(email, name)) {
            return "redirect:/products/all";
        } else {
            model.addAttribute("error", "Invalid email or name");
            return "login";
        }
    }
}
