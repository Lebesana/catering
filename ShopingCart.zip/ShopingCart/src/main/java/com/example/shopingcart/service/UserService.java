package com.example.shopingcart.service;

import com.example.shopingcart.domain.User;
import com.example.shopingcart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Service
@Transactional
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private static final Map<String, String> users = new HashMap<>();

    static {
        users.put("user1@gmail.com", "user1");
        users.put("user2@gmail.com", "user2");
    }

    public void saveInitialBatch() {
        for (Map.Entry<String, String> entry : users.entrySet()) {
            String email = entry.getKey();
            String name = entry.getValue();
            User user = new User(email, name);
            userRepository.save(user);
        }
    }

    public boolean authenticate(String email, String name) {
        User user = userRepository.findByEmail(email);
        return user != null && user.getName().equals(name);
    }
}
