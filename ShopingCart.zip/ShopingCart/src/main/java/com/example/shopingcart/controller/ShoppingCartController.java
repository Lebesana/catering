package com.example.shopingcart.controller;

import com.example.shopingcart.domain.ShoppingCart;
import com.example.shopingcart.dto.ShoppingCartDTO;
import com.example.shopingcart.service.ShoppingCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/shoppingCart")
public class ShoppingCartController {

    @Autowired
    private ShoppingCartService shoppingCartService;

    @PostMapping(produces = "application/json", consumes = "application/json")
    @ResponseBody
    public ShoppingCart addProductItem(@RequestBody ShoppingCartDTO shoppingCartDTO) {
        return shoppingCartService.saveProducts(shoppingCartDTO);
    }

    @GetMapping(produces = "application/json")
    @ResponseBody
    public List<ShoppingCart> getAll(){
        return shoppingCartService.findAll();
    }


    @RequestMapping(value = "/update/{id}", method = RequestMethod.PUT, produces = "application/json", consumes = "application/json")
    @ResponseBody
    public ShoppingCart updateCartItem(@PathVariable("id") Long itemId, @RequestBody ShoppingCartDTO cartItem) {
        return shoppingCartService.updateProduct(cartItem, itemId);
    }




    @DeleteMapping("/{id}")
    @ResponseBody
    public void deleteProductItem(@PathVariable("id") Long id) {
        shoppingCartService.deleteProduct(id);
    }

//    @DeleteMapping
//    @ResponseBody
//    public void clearCart() {
//        shoppingCartService.clearShoppingCart();
//    }

    @PostMapping("/purchase/{id}")
    @ResponseBody
    public void purchaseProducts(@PathVariable("id") Long id) {
        shoppingCartService.purchaseProducts(id);
    }
    @GetMapping("/view")
    public String viewShoppingCart(Model model) {
        List<ShoppingCart> shoppingCartItems = shoppingCartService.findAll();
        model.addAttribute("shoppingCartItems", shoppingCartItems);
        return "shoppingCartView";
    }
}
