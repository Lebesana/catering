package com.example.shopingcart.service;


import com.example.shopingcart.domain.Product;
import com.example.shopingcart.domain.ShoppingCart;
import com.example.shopingcart.dto.ShoppingCartDTO;
import com.example.shopingcart.repository.ProductRepository;
import com.example.shopingcart.repository.ShoppingCartRepository;
import com.example.shopingcart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;


@Service
@Transactional
public class ShoppingCartService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ShoppingCartRepository shoppingCartRepository;

    public ShoppingCart saveProducts(ShoppingCartDTO shoppingCartDTO) {
        ShoppingCart shoppingCart = new ShoppingCart();
        Product product = productRepository.findById(shoppingCartDTO.getProductId()).get();
        shoppingCart.setProduct(product);
        shoppingCart.setUser(userRepository.findById(1L).get());
        shoppingCart.setStatus(shoppingCartDTO.getStatus());
        shoppingCart.setDate(new Date());
        shoppingCart.setStock(shoppingCartDTO.getStock());
        shoppingCart.setAmount(product.getUnitPrice() * shoppingCartDTO.getStock());

        return shoppingCartRepository.save(shoppingCart);
    }


    public List<ShoppingCart> findAll() {
//        return shoppingCartRepository.findAll();
        return shoppingCartRepository.findByStatus("NOT_PURCHASED");
    }

    public ShoppingCart updateProduct(ShoppingCartDTO shoppingCartDTO, Long id) {
        ShoppingCart updateItem = shoppingCartRepository.findById(id).get();
        updateItem.setStock(shoppingCartDTO.getStock());
        updateItem.setAmount(updateItem.getProduct().getUnitPrice() * shoppingCartDTO.getStock());
        return shoppingCartRepository.save(updateItem);
    }

    public void deleteProduct(Long id) {
        shoppingCartRepository.deleteById(id);
    }

    public void clearShoppingCart( ) {
        shoppingCartRepository.deleteAll(findAll());
    }


    public List<ShoppingCart> findByPurchased() {
        return shoppingCartRepository.findByStatus("PURCHASED");
    }


    public void purchaseProducts(Long id) {
        List<ShoppingCart> shoppingCarts = shoppingCartRepository.findAllByUser_Id(id);
        for (ShoppingCart cart : shoppingCarts) {
            cart.setStatus("PURCHASED");
        }
        shoppingCartRepository.saveAll(shoppingCarts);

    }
}
