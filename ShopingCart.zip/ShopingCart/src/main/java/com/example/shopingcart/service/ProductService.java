package com.example.shopingcart.service;

import com.example.shopingcart.domain.Product;
import com.example.shopingcart.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.ArrayList;
import java.util.List;


@Service
@Transactional
public class ProductService{

    @Autowired
    private ProductRepository productRepository;

    private static List<Product> products = new ArrayList<>();

    static {
        products.add(new Product(120.0d, 1000, "Stainless Steel Mixing Bowls Set", "Mixing Bowls"));
        products.add(new Product(80.0d, 500, "Non-Stick Cooking Pots and Pans Set", "Cookware Set"));
        products.add(new Product(2000.0d, 100, "Commercial Food Processor", "Food Processor"));
        products.add(new Product(1500.0d, 400, "Professional Chef's Knife Set", "Knife Set"));
        products.add(new Product(500.0d, 800, "Chafing Dish Buffet Set", "Chafing Dish"));
        products.add(new Product(3000.0d, 800, "Industrial Food Mixer", "Food Mixer"));
        products.add(new Product(15000.0d, 800, "Commercial Refrigerator", "Refrigerator"));
        products.add(new Product(500.0d, 800, "Restaurant Grade Espresso Machine", "Espresso Machine"));
        products.add(new Product(700.0d, 800, "Stainless Steel Serving Cart", "Serving Cart"));
        products.add(new Product(5000.0d, 800, "Commercial Gas Grill", "Gas Grill"));
    }


    public void saveInitialBatch(){
        productRepository.saveAll(products);
    }


    public List<Product> findAll(){
        return productRepository.findAll();
    }


}
