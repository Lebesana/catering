package com.example.shopingcart.controller;

import com.example.shopingcart.domain.ShoppingCart;
import com.example.shopingcart.service.ShoppingCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/history")
public class HistoryController {

    @Autowired
    private ShoppingCartService shoppingCartService;

    @GetMapping
    public String getAll(Model model){
        List<ShoppingCart> shoppingHistory = shoppingCartService.findByPurchased();
        model.addAttribute("shoppingHistory", shoppingHistory);
        return "history";
    }
}
