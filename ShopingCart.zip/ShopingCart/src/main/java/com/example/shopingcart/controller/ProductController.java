package com.example.shopingcart.controller;

import com.example.shopingcart.domain.Product;
import com.example.shopingcart.domain.ShoppingCart;
import com.example.shopingcart.dto.ProductDTO;
import com.example.shopingcart.repository.ProductRepository;
import com.example.shopingcart.repository.ShoppingCartRepository;
import com.example.shopingcart.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller // Change to @Controller
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ShoppingCartRepository shoppingCartRepository;

    @GetMapping("/all")
    public String showAllProducts(Model model) {
        List<Product> products = productService.findAll();
        List<ShoppingCart> shoppingCartItems = shoppingCartRepository.findAllByUser_Id(1L); // assuming user ID 1 for simplicity

        for (ShoppingCart cartItem : shoppingCartItems) {
            for (Product product : products) {
                if (product.getId().equals(cartItem.getProduct().getId())) {
                    product.setQuantity(product.getQuantity() - cartItem.getStock());
                }
            }
        }

        model.addAttribute("products", products);
        return "allProducts";
    }

    @GetMapping("/addProduct") // Change mapping to /products/addProduct
    public String showAddProductForm(Model model) {
        model.addAttribute("product", new ProductDTO());
        return "addProduct";
    }

    @PostMapping("/add-product") // Change mapping to /products/add-product
    public String addProduct(@ModelAttribute ProductDTO productDTO) {
        Product product = new Product(productDTO.getUnitPrice(), productDTO.getQuantity(), productDTO.getDescription(), productDTO.getName());
        productRepository.save(product);
        return "redirect:/products/addProduct"; // Correct redirect URL
    }
}
